
require('dotenv').config();
const express = require('express');
const { GoogleGenerativeAI } = require('@google/generative-ai');

const app = express();
const port = 3000;

// Express 앱이 JSON 요청 본문을 파싱하고, 정적 파일을 제공하도록 설정합니다.
app.use(express.json());
app.use(express.static('.')); // 현재 디렉토리의 파일들(index.html 등)을 제공합니다.

// Gemini API 클라이언트를 초기화합니다.
const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);

// 화원중학교에 대한 기본 정보를 변수로 저장합니다.
const hwawonInfo = `
- 학교명: 화원중학교 (花園中學校, Hwawon Middle School)
- 주소: 대구광역시 달성군 화원읍 성암로 48 (본리리)
- 개교: 2000년
- 유형: 공립 남녀공학 중학교
- 교장: 노홍인 (2025년 기준 제13대)
- 교감: 김O희
- 교훈: 바르게 살자
- 상징:
  - 교목: 느티나무 (의미: 화합과 통일, 무궁한 번영과 발전, 선진국으로서의 기상)
  - 교화: 장미 (의미: 사랑, 정열, 진취성, 강인한 끈기, 밝고 아름다운 진취적 기상)
- 학생 수: 293명 (2025년 3월 기준)
- 교직원 수: 49명 (2025년 3월 기준)
- 관할 교육청: 대구광역시달성교육지원청
- 홈페이지: [화원중학교 홈페이지](https://hw.dge.ms.kr/hwm/main.do)

- 학교 연혁:
  - 2000-03-01: 초대 배중웅 교장 취임
  - 2000-03-03: 제1회 입학식 (8학급, 272명)
  - 2001-05-06: 학교교육계획서 우수학교 선정 (교육감)
  - 2003-02-12: 제1회 졸업식 (312명)
  - 2005-12-20: 전국 100대 교육과정 최우수학교 선정 (교육인적자원부장관)
  - 2007-12-27: 학교평가 최우수상 수상 (교육감)
  - 2011-12-19: 전국 100대 교육과정 최우수학교 재선정 (교육과학기술부 장관)
  - 2012-05-28: 제41회 전국소년체전 태권도 금메달 1, 동메달 1 수상
  - 2013-05-27: 제42회 전국소년체전 태권도 금메달 2개 획득
  - 2014-01-15: 2013학년도 학교평가 최우수 선정 (교육감)
  - 2016-09-24: 대구광역시교육감배 줄넘기 대회 우승 (3연패)
  - 2017-03-01: 제9대 남정순 교장 취임
  - 2020-03-01: 제10대 장석두 교장 취임
  - 2021-09-01: 제11대 김현순 교장 취임
  - 2024-03-01: 제12대 신재건 교장 취임
  - 2024-03-04: 제25회 입학식 (107명)
  - 2025-03-01: 제13대 노홍인 교장 취임
  - 2025-03-04: 제26회 입학식 (106명)

- 교가:
  (1절) 비슬산 봉우리에 떠-오른 태양
  찬란한 그 햇살을 가슴에 안고
  세계로 미래로 뻗어 나-가-는
  희망의 은빛날개 더욱 빛난다
  (후렴) 올려라 푸른깇발 새역사 앞에
  힘차게 전진한다 화원중학교

- 이용 가능한 대중교통 (버스):
  - 화동초등학교앞 정류장: 달서3
  - 화동초등학교건너 정류장: 달서3
  - 새터건너 정류장: 달성2 (본리2리 방향)
  - 새터앞 정류장: 달성2 (본리2리 방향)
  - 본리지구앞 정류장: 623, 653, 달서3
  - 본리지구건너 정류장: 623, 653, 달서3, 달성1
`;

// '/chat' 엔드포인트로 POST 요청이 오면 처리합니다.
app.post('/chat', async (req, res) => {
    try {
        const userMessage = req.body.message;

        // 특정 질문에 대해 직접 응답
        if (userMessage.includes('사이트') || userMessage.includes('홈페이지') || userMessage.includes('주소')) {
            return res.json({ reply: '[화원중학교 홈페이지](https://hw.dge.ms.kr/hwm/main.do)' });
        }

        const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });

        // Gemini에게 역할을 부여하고, 기본 정보를 제공하며, 사용자의 질문에 답변하도록 프롬프트를 구성합니다.
        const prompt = `
            당신은 화원중학교의 모든 것을 알고 있는 친절한 AI 챗봇입니다.
            아래 제공된 정보를 바탕으로 학생이나 학부모의 질문에 답변해주세요.
            정보에 없는 내용이라면 "해당 정보는 제가 알지 못하는 내용이에요. 학교 행정실에 문의해보시는 건 어떨까요?" 라고 부드럽게 안내해주세요.
            답변은 항상 한국어로, 완전한 문장으로 친절하게 해주세요. 링크를 포함할 경우, 반드시 Markdown 형식([링크 텍스트](URL))으로만 제공하고, HTML 태그나 HTML 속성(예: target="_blank")은 절대 사용하지 마세요. 어떠한 경우에도 HTML 태그나 속성을 답변에 포함하지 마세요.

            --- 화원중학교 정보 ---
            ${hwawonInfo}
            --------------------

            사용자 질문: ${userMessage}
            챗봇 답변:
        `;

        const result = await model.generateContent(prompt);
        const response = await result.response;
        const text = response.text();

        res.json({ reply: text });

    } catch (error) {
        console.error("Error processing chat:", error);
        res.status(500).json({ error: '챗봇 응답 생성에 실패했습니다.' });
    }
});

app.listen(port, () => {
    console.log(`서버가 http://localhost:${port} 에서 실행 중입니다.`);
});
